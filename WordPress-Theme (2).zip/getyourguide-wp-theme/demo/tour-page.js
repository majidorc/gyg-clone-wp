// Tour page specific functionality
let participants = {
    adults: 2,
    children: 0
};

const prices = {
    adults: 45,
    children: 35
};

document.addEventListener('DOMContentLoaded', function() {
    initializeTourPage();
    updateTotalPrice();
    updateWishlistDisplay();
});

function initializeTourPage() {
    // Set minimum date to today
    const dateInput = document.getElementById('tour-date');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.min = today;
    }
    
    // Initialize wishlist from localStorage
    const savedWishlist = localStorage.getItem('demo_wishlist');
    if (savedWishlist) {
        try {
            window.userWishlist = JSON.parse(savedWishlist);
        } catch (e) {
            window.userWishlist = [];
        }
    } else {
        window.userWishlist = [];
    }
}

function changeMainImage(src) {
    const mainImage = document.getElementById('main-tour-image');
    if (mainImage) {
        mainImage.src = src;
    }
}

function openGallery() {
    showNotification('Photo gallery would open here - This is a demo!', 'info');
}

function updateQuantity(type, change) {
    const currentValue = participants[type];
    const newValue = Math.max(0, currentValue + change);
    
    // Ensure at least 1 adult
    if (type === 'adults' && newValue === 0) {
        showNotification('At least 1 adult is required', 'warning');
        return;
    }
    
    participants[type] = newValue;
    
    // Update display
    const countElement = document.getElementById(`${type}-count`);
    if (countElement) {
        countElement.textContent = newValue;
    }
    
    // Update total price
    updateTotalPrice();
}

function updateTotalPrice() {
    const total = (participants.adults * prices.adults) + (participants.children * prices.children);
    const totalElement = document.getElementById('total-price');
    if (totalElement) {
        totalElement.textContent = `$${total}`;
    }
}

function bookNow() {
    const dateInput = document.getElementById('tour-date');
    const timeInput = document.getElementById('tour-time');
    
    if (!dateInput.value) {
        showNotification('Please select a date', 'warning');
        return;
    }
    
    if (!timeInput.value) {
        showNotification('Please select a time', 'warning');
        return;
    }
    
    const total = (participants.adults * prices.adults) + (participants.children * prices.children);
    const bookingDetails = {
        tour: 'Skip-the-Line: Eiffel Tower Guided Tour',
        date: dateInput.value,
        time: timeInput.value,
        adults: participants.adults,
        children: participants.children,
        total: total
    };
    
    console.log('Booking details:', bookingDetails);
    showNotification(`Booking confirmed for ${bookingDetails.adults + bookingDetails.children} participants on ${bookingDetails.date} at ${bookingDetails.time}. Total: $${bookingDetails.total} - This is a demo!`, 'success');
}

function toggleWishlist(tourId) {
    if (!window.userWishlist) {
        window.userWishlist = [];
    }
    
    const index = window.userWishlist.indexOf(tourId);
    
    if (index > -1) {
        window.userWishlist.splice(index, 1);
        showNotification('Removed from wishlist', 'success');
    } else {
        window.userWishlist.push(tourId);
        showNotification('Added to wishlist', 'success');
    }
    
    // Save to localStorage
    localStorage.setItem('demo_wishlist', JSON.stringify(window.userWishlist));
    
    // Update UI
    updateWishlistDisplay();
    updateWishlistCount();
}

function updateWishlistDisplay() {
    const wishlistBtn = document.querySelector('.wishlist-add-btn');
    const isWishlisted = window.userWishlist && window.userWishlist.includes(1);
    
    if (wishlistBtn) {
        const icon = wishlistBtn.querySelector('i');
        if (isWishlisted) {
            icon.className = 'fas fa-heart';
            wishlistBtn.innerHTML = '<i class="fas fa-heart"></i> Remove from wishlist';
            wishlistBtn.style.color = '#ff6b35';
            wishlistBtn.style.borderColor = '#ff6b35';
        } else {
            icon.className = 'far fa-heart';
            wishlistBtn.innerHTML = '<i class="far fa-heart"></i> Add to wishlist';
            wishlistBtn.style.color = '#333';
            wishlistBtn.style.borderColor = '#d1d5db';
        }
    }
}

function updateWishlistCount() {
    const wishlistCountEl = document.querySelector('.wishlist-count');
    if (wishlistCountEl && window.userWishlist) {
        wishlistCountEl.textContent = window.userWishlist.length;
    }
}

function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    if (!notification) return;
    
    notification.textContent = message;
    notification.className = `notification ${type} show`;
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 5000);
}

// Export functions for global access
window.changeMainImage = changeMainImage;
window.openGallery = openGallery;
window.updateQuantity = updateQuantity;
window.bookNow = bookNow;
window.toggleWishlist = toggleWishlist;