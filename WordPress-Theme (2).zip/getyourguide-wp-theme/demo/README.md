# GetYourGuide WordPress Theme Demo

This is a live demo of the GetYourGuide WordPress theme that replicates the design and functionality of GetYourGuide.com.

## 🎯 Demo Features

### ✅ Implemented Features
- **Homepage Design**: Pixel-perfect recreation of GetYourGuide homepage
- **Responsive Layout**: Works perfectly on mobile, tablet, and desktop
- **Tour Cards**: Interactive tour cards with wishlist functionality
- **Search Functionality**: Live search with autocomplete suggestions
- **Category Filtering**: Filter tours by activity type
- **Tour Detail Page**: Complete tour page with booking form
- **Wishlist System**: Add/remove tours from wishlist (localStorage)
- **Mobile Menu**: Responsive hamburger navigation
- **Interactive Elements**: Hover effects, transitions, and animations

### 🎨 Design Elements
- **Color Scheme**: Authentic GetYourGuide colors (#ff6b35 orange, #3182ce blue)
- **Typography**: Inter font family matching GetYourGuide style
- **Icons**: Font Awesome icons for consistent UI
- **Images**: High-quality Unsplash images for destinations and tours
- **Layout**: CSS Grid and Flexbox for modern responsive design

### 🚀 JavaScript Features
- **AJAX Search**: Real-time search suggestions
- **Wishlist Management**: LocalStorage-based wishlist system
- **Dynamic Content**: JavaScript-powered tour filtering and rendering
- **Interactive Booking**: Tour booking form with validation
- **Notifications**: User feedback system
- **Mobile Navigation**: Touch-friendly mobile menu

## 📱 Pages Included

1. **Homepage** (`index.html`)
   - Hero section with search
   - Category tabs
   - Featured tours grid
   - Top destinations
   - Complete GetYourGuide layout

2. **Tour Detail Page** (`tour.html`)
   - Tour image gallery
   - Detailed tour information
   - Booking sidebar with pricing
   - Customer reviews
   - Related tours section

## 🛠 WordPress Theme Files

The actual WordPress theme includes:
- `style.css` - Main theme stylesheet
- `functions.php` - Theme functionality and hooks
- `index.php` - Homepage template
- `header.php` - Site header
- `footer.php` - Site footer
- `single-tour.php` - Individual tour page
- `archive-tour.php` - Tours listing page
- `js/main.js` - JavaScript functionality

## 📋 WordPress Features

When installed as a WordPress theme, this includes:
- **Custom Post Types**: Tours, Destinations
- **Custom Taxonomies**: Tour categories, Locations
- **Meta Fields**: Tour pricing, duration, highlights
- **Widget Areas**: Footer widgets, sidebar
- **Theme Customizer**: Logo, colors, layout options
- **WooCommerce Ready**: Integration for bookings
- **SEO Optimized**: Clean markup and meta tags

## 🎯 Use Cases

This theme is perfect for:
- **Travel Agencies**: Showcase tours and destinations
- **Tour Operators**: Manage bookings and activities
- **Activity Providers**: Highlight experiences
- **Travel Blogs**: Share travel content
- **Booking Platforms**: Create travel marketplaces

## 🔧 Installation

### As WordPress Theme:
1. Upload theme folder to `/wp-content/themes/`
2. Activate in WordPress admin
3. Configure theme options
4. Add tour content

### Demo Version:
The demo showcases the design and functionality without requiring WordPress installation.

## 📞 Support

For WordPress theme support and customization:
- Documentation: See main README.md
- Issues: WordPress admin help
- Customization: Contact theme developer

---

**Note**: This demo uses static data and localStorage for demonstration. The actual WordPress theme includes database integration and full CMS functionality.