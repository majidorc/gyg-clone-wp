# GetYourGuide WordPress Theme Development Todos - v2.0 (WooCommerce + ACF Integration)

## Theme Structure Setup
- [x] Rebuild theme files with WooCommerce integration
- [x] Update functions.php for WooCommerce + Bookings + ACF
- [x] Create WooCommerce template overrides

## WooCommerce Integration
- [x] Configure tours as WooCommerce products
- [x] Set up WooCommerce Bookings for date/time selection
- [x] Create custom product fields with ACF
- [x] Override WooCommerce templates to match GetYourGuide design

## ACF Field Groups
- [x] Create Tour Details field group
- [x] Add Tour Features field group
- [x] Set up Tour Gallery field group
- [x] Create Tour Itinerary field group

## Product/Booking System
- [x] Single product page redesign for tours
- [x] WooCommerce Bookings integration
- [ ] Real cart and checkout functionality
- [ ] Payment gateway integration

## Advanced Features
- [ ] Tour reviews system using WooCommerce reviews
- [ ] Inventory management for tour availability
- [ ] Variable pricing (adults/children/groups)
- [ ] Tour guide assignment system

## Homepage & Archive Updates
- [x] Update homepage to display WooCommerce products
- [x] Create shop page override
- [x] Update filtering to work with WooCommerce
- [x] Add to cart functionality on tour cards

## User Account Features
- [ ] My Account page customization
- [ ] Booking history and management
- [x] Wishlist integration with WooCommerce
- [ ] Customer dashboard

## Payment & Booking
- [ ] Multiple payment methods
- [ ] Booking confirmation emails
- [ ] Calendar availability system
- [ ] Booking management for admin

## Immediate Next Steps
- [x] Update JavaScript to work with new AJAX endpoints
- [ ] Test WooCommerce Bookings integration
- [ ] Add sample products for demonstration
- [ ] Create installation documentation
- [x] Fix CSS layout issues on single product pages
- [x] Test theme deployment with new WooCommerce integration

## Bug Fixes Completed
- [x] Fixed single product page layout (two-column with sidebar)
- [x] Added proper WooCommerce template overrides
- [x] Enhanced CSS for product gallery and booking forms
- [x] Improved mobile responsiveness for product pages
