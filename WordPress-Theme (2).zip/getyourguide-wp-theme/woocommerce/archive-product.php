<?php
/**
 * The Template for displaying product archives, including the main shop page
 * WooCommerce override for GetYourGuide design
 */

defined('ABSPATH') || exit;

get_header('shop'); ?>

<main id="main" class="site-main">
    <!-- Page Header -->
    <section class="shop-header">
        <div class="container">
            <div class="shop-header-content">
                <h1 class="shop-title">
                    <?php
                    if (is_shop()) {
                        echo 'Tours & Experiences';
                    } elseif (is_product_category()) {
                        single_cat_title();
                    } elseif (is_product_tag()) {
                        single_tag_title();
                    } else {
                        echo 'Products';
                    }
                    ?>
                </h1>

                <?php if (is_product_category() && category_description()) : ?>
                    <div class="shop-description">
                        <?php echo category_description(); ?>
                    </div>
                <?php endif; ?>

                <div class="shop-stats">
                    <span class="results-count">
                        <?php
                        $total = wc_get_loop_prop('total');
                        printf(_n('%d experience found', '%d experiences found', $total, 'getyourguide-clone'), $total);
                        ?>
                    </span>
                </div>
            </div>
        </div>
    </section>

    <!-- Filters Section -->
    <section class="shop-filters-section">
        <div class="container">
            <div class="filters-container">
                <!-- Search Bar -->
                <div class="filter-search">
                    <form class="search-form-shop" method="get" action="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">
                        <input type="search"
                               name="s"
                               value="<?php echo get_search_query(); ?>"
                               placeholder="Search tours and experiences"
                               class="search-input-shop">
                        <button type="submit" class="search-btn-shop">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="11" cy="11" r="8"></circle>
                                <path d="m21 21-4.35-4.35"></path>
                            </svg>
                        </button>
                    </form>
                </div>

                <!-- Category Filter Buttons -->
                <div class="filter-buttons">
                    <a href="<?php echo esc_url(remove_query_arg('product_cat')); ?>"
                       class="filter-btn <?php echo !is_product_category() ? 'active' : ''; ?>">
                        All Tours
                    </a>

                    <?php
                    $product_categories = get_terms(array(
                        'taxonomy' => 'product_cat',
                        'hide_empty' => true,
                        'exclude' => array(get_option('default_product_cat')),
                        'number' => 6,
                    ));

                    if (!is_wp_error($product_categories)) :
                        foreach ($product_categories as $category) :
                            $is_current = is_product_category($category->slug);
                            ?>
                            <a href="<?php echo esc_url(get_term_link($category)); ?>"
                               class="filter-btn <?php echo $is_current ? 'active' : ''; ?>">
                                <?php echo esc_html($category->name); ?>
                                <span class="filter-count">(<?php echo $category->count; ?>)</span>
                            </a>
                        <?php endforeach;
                    endif; ?>
                </div>

                <!-- Sort Options -->
                <div class="sort-options">
                    <?php woocommerce_catalog_ordering(); ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Products Grid -->
    <section class="shop-products-section">
        <div class="container">
            <?php if (woocommerce_product_loop()) : ?>

                <?php woocommerce_product_loop_start(); ?>

                <div class="products-grid">
                    <?php if (wc_get_loop_prop('is_shortcode')) : ?>
                        <?php
                        // For shortcodes, get products and display them
                        global $woocommerce_loop;
                        $woocommerce_loop['columns'] = 4;
                        ?>
                    <?php endif; ?>

                    <?php while (have_posts()) : the_post(); ?>
                        <?php
                        global $product;
                        getyourguide_shop_loop_item();
                        ?>
                    <?php endwhile; ?>
                </div>

                <?php woocommerce_product_loop_end(); ?>

                <!-- Pagination -->
                <div class="shop-pagination">
                    <?php woocommerce_pagination(); ?>
                </div>

            <?php else : ?>

                <!-- No Products Found -->
                <div class="no-products-found">
                    <div class="no-products-content">
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                            <circle cx="11" cy="11" r="8"></circle>
                            <path d="m21 21-4.35-4.35"></path>
                        </svg>
                        <h2>No tours found</h2>
                        <p>Sorry, we couldn't find any tours matching your criteria. Try adjusting your filters or search terms.</p>
                        <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>" class="view-all-btn">
                            View All Tours
                        </a>
                    </div>
                </div>

            <?php endif; ?>
        </div>
    </section>

    <!-- Newsletter Section -->
    <section class="newsletter-section">
        <div class="container">
            <div class="newsletter-content">
                <div class="newsletter-text">
                    <h2>Don't miss out on new experiences</h2>
                    <p>Get notified about the latest tours and special offers in your favorite destinations.</p>
                </div>
                <div class="newsletter-form-wrapper">
                    <form class="newsletter-signup" id="shop-newsletter">
                        <input type="email" placeholder="Your email address" required>
                        <button type="submit">Subscribe</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</main>

<style>
/* Shop Page Styles */
.shop-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 3rem 0;
}

.shop-header-content {
    text-align: center;
}

.shop-title {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    font-weight: 700;
}

.shop-description {
    font-size: 1.1rem;
    opacity: 0.9;
    margin-bottom: 1rem;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

.shop-stats {
    font-size: 0.875rem;
    opacity: 0.8;
}

.shop-filters-section {
    background: white;
    padding: 2rem 0;
    border-bottom: 1px solid #e2e8f0;
    position: sticky;
    top: 70px;
    z-index: 100;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.filters-container {
    display: flex;
    align-items: center;
    gap: 2rem;
    flex-wrap: wrap;
}

.filter-search {
    flex: 1;
    min-width: 300px;
}

.search-form-shop {
    position: relative;
    display: flex;
    max-width: 400px;
}

.search-input-shop {
    flex: 1;
    padding: 12px 16px;
    border: 1px solid #e2e8f0;
    border-radius: 8px 0 0 8px;
    font-size: 16px;
    outline: none;
}

.search-input-shop:focus {
    border-color: #3182ce;
    box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.1);
}

.search-btn-shop {
    background: #3182ce;
    color: white;
    border: none;
    padding: 12px 16px;
    border-radius: 0 8px 8px 0;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.search-btn-shop:hover {
    background: #2c5aa0;
}

.filter-buttons {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
}

.filter-btn {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1rem;
    border: 1px solid #e2e8f0;
    border-radius: 20px;
    background: white;
    color: #344053;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.875rem;
    font-weight: 500;
}

.filter-btn:hover,
.filter-btn.active {
    background: #3182ce;
    color: white;
    border-color: #3182ce;
    text-decoration: none;
}

.filter-count {
    font-size: 0.75rem;
    opacity: 0.8;
}

.sort-options {
    margin-left: auto;
}

.sort-options .woocommerce-ordering select {
    padding: 0.5rem 1rem;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: white;
    color: #344053;
    cursor: pointer;
}

.shop-products-section {
    padding: 3rem 0;
}

.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 2rem;
    margin-bottom: 3rem;
}

.shop-pagination {
    display: flex;
    justify-content: center;
    margin-top: 3rem;
}

.shop-pagination .woocommerce-pagination {
    text-align: center;
}

.shop-pagination .page-numbers {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    margin: 0 4px;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    text-decoration: none;
    color: #344053;
    transition: all 0.2s ease;
}

.shop-pagination .page-numbers:hover,
.shop-pagination .page-numbers.current {
    background: #3182ce;
    color: white;
    border-color: #3182ce;
}

.no-products-found {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 400px;
}

.no-products-content {
    text-align: center;
    max-width: 400px;
}

.no-products-content svg {
    color: #a0aec0;
    margin-bottom: 1rem;
}

.no-products-content h2 {
    color: #1a202c;
    margin-bottom: 1rem;
}

.no-products-content p {
    color: #4a5568;
    margin-bottom: 2rem;
}

.view-all-btn {
    display: inline-block;
    background: #3182ce;
    color: white;
    padding: 0.75rem 1.5rem;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 600;
    transition: background-color 0.2s ease;
}

.view-all-btn:hover {
    background: #2c5aa0;
    color: white;
}

/* Mobile Responsive */
@media (max-width: 768px) {
    .filters-container {
        flex-direction: column;
        align-items: stretch;
        gap: 1rem;
    }

    .filter-search {
        min-width: auto;
    }

    .sort-options {
        margin-left: 0;
        margin-top: 1rem;
    }

    .products-grid {
        grid-template-columns: 1fr;
    }

    .filter-buttons {
        justify-content: center;
    }
}

/* Newsletter Section */
.newsletter-section {
    background: #f7fafc;
    padding: 4rem 0;
    margin-top: 3rem;
}

.newsletter-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 3rem;
    align-items: center;
}

.newsletter-text h2 {
    font-size: 2rem;
    margin-bottom: 1rem;
    color: #1a202c;
}

.newsletter-text p {
    font-size: 1.1rem;
    color: #4a5568;
    margin: 0;
}

.newsletter-signup {
    display: flex;
    gap: 0.5rem;
    max-width: 400px;
    margin-left: auto;
}

.newsletter-signup input {
    flex: 1;
    padding: 1rem;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    font-size: 16px;
}

.newsletter-signup button {
    background: #ff6b35;
    color: white;
    border: none;
    padding: 1rem 2rem;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.newsletter-signup button:hover {
    background: #e55a2b;
}

@media (max-width: 768px) {
    .newsletter-content {
        grid-template-columns: 1fr;
        gap: 2rem;
        text-align: center;
    }

    .newsletter-signup {
        margin: 0 auto;
    }
}

/* WooCommerce Overrides */
.woocommerce-ordering {
    margin: 0;
}

.woocommerce-ordering select {
    padding: 0.5rem 1rem;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: white;
    color: #344053;
    cursor: pointer;
    font-size: 0.875rem;
}

.woocommerce-result-count {
    display: none;
}

/* Hide default WooCommerce elements we're replacing */
.woocommerce-notices-wrapper {
    margin-bottom: 2rem;
}

.woocommerce-breadcrumb {
    display: none;
}

.woocommerce .woocommerce-loop-product__title {
    display: none;
}

.woocommerce ul.products {
    display: contents;
}

.woocommerce ul.products li.product {
    width: auto;
    float: none;
    margin: 0;
    background: none;
    border: none;
    box-shadow: none;
}
</style>

<script>
// Shop page specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Newsletter signup
    const newsletterForm = document.getElementById('shop-newsletter');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;

            // Show success message
            if (typeof GetyourguideTheme !== 'undefined') {
                GetyourguideTheme.showNotification('Thank you for subscribing!', 'success');
            } else {
                alert('Thank you for subscribing!');
            }

            this.querySelector('input[type="email"]').value = '';
        });
    }

    // Enhanced filtering (if needed)
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Add loading state
            this.style.opacity = '0.7';
            this.style.pointerEvents = 'none';
        });
    });
});
</script>

<?php get_footer('shop'); ?>
