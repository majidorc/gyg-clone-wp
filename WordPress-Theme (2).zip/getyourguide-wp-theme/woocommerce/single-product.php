<?php
/**
 * The Template for displaying all single products
 * WooCommerce override for GetYourGuide design
 */

defined('ABSPATH') || exit;

get_header('shop'); ?>

<main id="main" class="site-main">
    <?php while (have_posts()) : the_post();
        global $product;

        // Get ACF fields
        $duration = get_field('tour_duration');
        $group_size = get_field('tour_group_size');
        $meeting_point = get_field('tour_meeting_point');
        $languages = get_field('tour_languages');
        $difficulty = get_field('tour_difficulty');
        $highlights = get_field('tour_highlights');
        $included = get_field('tour_included');
        $not_included = get_field('tour_not_included');
        $itinerary = get_field('tour_itinerary');
        $gallery = get_field('tour_gallery');
        $video_url = get_field('tour_video');
        $features = get_field('tour_features_badges');

        $categories = get_the_terms($product->get_id(), 'product_cat');
        $rating_count = $product->get_rating_count();
        $average_rating = $product->get_average_rating();
        ?>

        <!-- Breadcrumb -->
        <div class="breadcrumb-section">
            <div class="container">
                <nav class="breadcrumb">
                    <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                    <span class="separator">></span>
                    <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">Tours</a>
                    <span class="separator">></span>
                    <?php if ($categories && !is_wp_error($categories)) : ?>
                        <a href="<?php echo esc_url(get_term_link($categories[0])); ?>"><?php echo esc_html($categories[0]->name); ?></a>
                        <span class="separator">></span>
                    <?php endif; ?>
                    <span class="current"><?php the_title(); ?></span>
                </nav>
            </div>
        </div>

        <!-- Product Header -->
        <section class="product-header">
            <div class="container">
                <div class="product-header-content">
                    <div class="product-header-left">
                        <?php if ($categories && !is_wp_error($categories)) : ?>
                            <div class="product-category">
                                <span class="category-badge"><?php echo esc_html($categories[0]->name); ?></span>
                            </div>
                        <?php endif; ?>

                        <h1 class="product-title"><?php the_title(); ?></h1>

                        <div class="product-meta-header">
                            <?php if ($rating_count > 0) : ?>
                                <div class="product-rating">
                                    <div class="rating-stars"><?php echo wc_get_rating_html($average_rating, $rating_count); ?></div>
                                    <span class="rating-text"><?php printf(__('%s (%d reviews)', 'getyourguide-clone'), number_format($average_rating, 1), $rating_count); ?></span>
                                </div>
                            <?php endif; ?>

                            <div class="product-actions-header">
                                <button class="product-action-btn wishlist-btn" data-product-id="<?php echo $product->get_id(); ?>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M20.84,4.61a5.5,5.5 0 0,0 -7.78,0L12,5.67L10.94,4.61a5.5,5.5 0 0,0 -7.78,7.78l1.06,1.06L12,21.23l7.78,-7.78l1.06,-1.06a5.5,5.5 0 0,0 0,-7.78z"></path>
                                    </svg>
                                    <?php echo getyourguide_is_in_wishlist($product->get_id()) ? 'Remove from wishlist' : 'Add to wishlist'; ?>
                                </button>
                                <button class="product-action-btn share-btn" onclick="shareProduct()">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <circle cx="18" cy="5" r="3"></circle>
                                        <circle cx="6" cy="12" r="3"></circle>
                                        <circle cx="18" cy="19" r="3"></circle>
                                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
                                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
                                    </svg>
                                    Share
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Product Gallery -->
        <section class="product-gallery-section">
            <div class="container">
                <div class="product-gallery">
                    <div class="main-image">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('tour-hero', array('class' => 'product-main-image')); ?>
                        <?php else : ?>
                            <img src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=1200&h=800&fit=crop"
                                 alt="<?php the_title(); ?>" class="product-main-image">
                        <?php endif; ?>

                        <div class="image-overlay">
                            <?php if ($gallery || $video_url) : ?>
                                <button class="view-all-photos" onclick="openGalleryModal()">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                        <circle cx="8.5" cy="8.5" r="1.5"></circle>
                                        <polyline points="21,15 16,10 5,21"></polyline>
                                    </svg>
                                    View all photos
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if ($gallery) : ?>
                        <div class="thumbnail-images">
                            <div class="thumbnail-grid">
                                <?php foreach (array_slice($gallery, 0, 4) as $image) : ?>
                                    <img src="<?php echo esc_url($image['sizes']['tour-thumbnail']); ?>"
                                         alt="<?php echo esc_attr($image['alt']); ?>"
                                         onclick="openGalleryModal(<?php echo $image['ID']; ?>)">
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Product Content -->
        <section class="product-content-section">
            <div class="container">
                <div class="product-content-grid">
                    <!-- Main Content -->
                    <div class="product-main-content">
                        <!-- About This Experience -->
                        <div class="content-block">
                            <h2>About this activity</h2>
                            <div class="activity-features">
                                <?php if ($features && in_array('free_cancellation', $features)) : ?>
                                    <div class="feature-item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <polyline points="12,6 12,12 16,14"></polyline>
                                        </svg>
                                        <div>
                                            <strong>Free cancellation</strong>
                                            <p>Cancel up to 24 hours in advance for a full refund</p>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if ($features && in_array('instant_confirmation', $features)) : ?>
                                    <div class="feature-item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
                                        </svg>
                                        <div>
                                            <strong>Reserve now & pay later</strong>
                                            <p>Keep your travel plans flexible — book your spot and pay nothing today</p>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if ($duration) : ?>
                                    <div class="feature-item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <polyline points="12,6 12,12 16,14"></polyline>
                                        </svg>
                                        <div>
                                            <strong>Duration <?php echo esc_html($duration); ?></strong>
                                            <p>Check availability to see starting times</p>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if ($features && in_array('skip_line', $features)) : ?>
                                    <div class="feature-item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"></polyline>
                                        </svg>
                                        <div>
                                            <strong>Skip the line</strong>
                                            <p>Don't wait in line with this skip-the-line ticket</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="product-description">
                                <?php the_content(); ?>
                            </div>
                        </div>

                        <!-- Highlights -->
                        <?php if ($highlights) : ?>
                            <div class="content-block">
                                <h2>Highlights</h2>
                                <ul class="highlights-list">
                                    <?php foreach ($highlights as $highlight) : ?>
                                        <li><?php echo esc_html($highlight['highlight_text']); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <!-- Itinerary -->
                        <?php if ($itinerary) : ?>
                            <div class="content-block">
                                <h2>Itinerary</h2>
                                <div class="itinerary-timeline">
                                    <?php foreach ($itinerary as $item) : ?>
                                        <div class="itinerary-item">
                                            <?php if ($item['itinerary_time']) : ?>
                                                <div class="itinerary-time"><?php echo esc_html($item['itinerary_time']); ?></div>
                                            <?php endif; ?>
                                            <div class="itinerary-content">
                                                <h3><?php echo esc_html($item['itinerary_title']); ?></h3>
                                                <?php if ($item['itinerary_description']) : ?>
                                                    <p><?php echo esc_html($item['itinerary_description']); ?></p>
                                                <?php endif; ?>
                                                <?php if ($item['itinerary_location']) : ?>
                                                    <div class="itinerary-location">
                                                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                                            <circle cx="12" cy="10" r="3"></circle>
                                                        </svg>
                                                        <?php echo esc_html($item['itinerary_location']); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- What's Included -->
                        <div class="content-block">
                            <div class="includes-grid">
                                <?php if ($included) : ?>
                                    <div class="includes-section">
                                        <h3>Includes</h3>
                                        <ul class="includes-list">
                                            <?php foreach ($included as $item) : ?>
                                                <li class="included-item">
                                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                        <polyline points="20,6 9,17 4,12"></polyline>
                                                    </svg>
                                                    <?php echo esc_html($item['included_item']); ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if ($not_included) : ?>
                                    <div class="includes-section">
                                        <h3>Not suitable for</h3>
                                        <ul class="includes-list">
                                            <?php foreach ($not_included as $item) : ?>
                                                <li class="not-included-item">
                                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                        <line x1="18" y1="6" x2="6" y2="18"></line>
                                                        <line x1="6" y1="6" x2="18" y2="18"></line>
                                                    </svg>
                                                    <?php echo esc_html($item['not_included_item']); ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Important Information -->
                        <div class="content-block">
                            <h2>Important information</h2>
                            <div class="important-info">
                                <?php if ($languages) : ?>
                                    <div class="info-section">
                                        <h3>Languages</h3>
                                        <p><?php echo esc_html(implode(', ', array_map('ucfirst', $languages))); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if ($difficulty) : ?>
                                    <div class="info-section">
                                        <h3>Difficulty Level</h3>
                                        <p><?php echo esc_html(ucfirst($difficulty)); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if ($group_size) : ?>
                                    <div class="info-section">
                                        <h3>Group Size</h3>
                                        <p>Maximum <?php echo esc_html($group_size); ?> participants</p>
                                    </div>
                                <?php endif; ?>

                                <?php if ($meeting_point) : ?>
                                    <div class="info-section">
                                        <h3>Meeting Point</h3>
                                        <p><?php echo esc_html($meeting_point); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Booking Sidebar -->
                    <div class="product-booking-sidebar">
                        <div class="booking-card">
                            <div class="booking-price">
                                <span class="price-from">From</span>
                                <span class="price-amount"><?php echo $product->get_price_html(); ?></span>
                                <span class="price-per">per person</span>
                            </div>

                            <?php if ($features && in_array('free_cancellation', $features)) : ?>
                                <div class="booking-guarantee">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                                    </svg>
                                    <span>Lowest price & money back guarantee</span>
                                </div>
                            <?php endif; ?>

                            <!-- WooCommerce Add to Cart Form -->
                            <div class="woocommerce-booking-form">
                                <?php woocommerce_template_single_add_to_cart(); ?>
                            </div>

                            <?php if ($features) : ?>
                                <div class="booking-features">
                                    <?php if (in_array('free_cancellation', $features)) : ?>
                                        <div class="booking-feature">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <polyline points="20,6 9,17 4,12"></polyline>
                                            </svg>
                                            Free cancellation up to 24 hours in advance
                                        </div>
                                    <?php endif; ?>
                                    <?php if (in_array('instant_confirmation', $features)) : ?>
                                        <div class="booking-feature">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <polyline points="20,6 9,17 4,12"></polyline>
                                            </svg>
                                            Reserve now & pay later to secure your spot
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Related Products -->
                        <?php
                        $related_products = wc_get_related_products($product->get_id(), 4);
                        if (!empty($related_products)) : ?>
                            <div class="related-products">
                                <h3>You might also like...</h3>
                                <?php foreach ($related_products as $related_id) :
                                    $related_product = wc_get_product($related_id);
                                    if (!$related_product) continue;
                                    ?>
                                    <div class="related-product-item">
                                        <a href="<?php echo get_permalink($related_id); ?>" class="related-product-link">
                                            <div class="related-product-image">
                                                <?php echo $related_product->get_image('tour-thumbnail'); ?>
                                            </div>
                                            <div class="related-product-content">
                                                <h4><?php echo $related_product->get_name(); ?></h4>
                                                <div class="related-product-meta">
                                                    <?php if ($related_product->get_average_rating()) : ?>
                                                        <span class="rating">★ <?php echo number_format($related_product->get_average_rating(), 1); ?></span>
                                                    <?php endif; ?>
                                                    <span class="price">From <?php echo $related_product->get_price_html(); ?></span>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <!-- Reviews Section -->
        <section class="reviews-section">
            <div class="container">
                <?php comments_template(); ?>
            </div>
        </section>

    <?php endwhile; ?>
</main>

<style>
/* Single Product Page Styles */
.breadcrumb-section {
    background: #f7fafc;
    padding: 1rem 0;
}

.breadcrumb {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.875rem;
}

.breadcrumb .separator {
    color: #718096;
}

.breadcrumb .current {
    color: #718096;
}

.product-header {
    padding: 2rem 0;
}

.product-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 2rem;
}

.category-badge {
    background: #ff6b35;
    color: white;
    padding: 4px 12px;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.product-title {
    font-size: 2rem;
    margin: 1rem 0;
    color: #1a202c;
}

.product-meta-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 2rem;
    flex-wrap: wrap;
}

.product-actions-header {
    display: flex;
    gap: 1rem;
}

.product-action-btn {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: white;
    color: #344053;
    cursor: pointer;
    transition: all 0.2s ease;
    text-decoration: none;
    font-size: 0.875rem;
}

.product-action-btn:hover {
    border-color: #3182ce;
    color: #3182ce;
}

.product-gallery-section {
    margin-bottom: 2rem;
}

.product-gallery {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1rem;
    height: 500px;
}

.main-image {
    position: relative;
    overflow: hidden;
    border-radius: 12px;
}

.product-main-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.image-overlay {
    position: absolute;
    bottom: 1rem;
    right: 1rem;
}

.view-all-photos {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1rem;
    background: rgba(255, 255, 255, 0.9);
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 500;
    backdrop-filter: blur(10px);
}

.thumbnail-images {
    display: flex;
    flex-direction: column;
}

.thumbnail-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
    height: 100%;
}

.thumbnail-grid img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 8px;
    cursor: pointer;
    transition: transform 0.2s ease;
}

.thumbnail-grid img:hover {
    transform: scale(1.05);
}

/* Main Content Grid - This is the key fix */
.product-content-section {
    padding: 2rem 0;
}

.product-content-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 3rem;
    align-items: start;
}

.product-main-content {
    max-width: none;
}

.content-block {
    margin-bottom: 3rem;
    padding-bottom: 2rem;
    border-bottom: 1px solid #e2e8f0;
}

.content-block:last-child {
    border-bottom: none;
}

.content-block h2 {
    font-size: 1.5rem;
    margin-bottom: 1.5rem;
    color: #1a202c;
}

.content-block h3 {
    font-size: 1.25rem;
    margin-bottom: 1rem;
    color: #1a202c;
}

.activity-features {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    margin-bottom: 2rem;
}

.feature-item {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    padding: 1rem;
    background: #f7fafc;
    border-radius: 8px;
}

.feature-item svg {
    color: #3182ce;
    margin-top: 2px;
    flex-shrink: 0;
}

.feature-item strong {
    display: block;
    margin-bottom: 0.25rem;
    color: #1a202c;
}

.feature-item p {
    color: #4a5568;
    font-size: 0.875rem;
    margin: 0;
}

.product-description {
    line-height: 1.6;
    color: #4a5568;
}

.highlights-list {
    list-style: none;
    margin: 0;
    padding: 0;
}

.highlights-list li {
    padding: 0.75rem 0;
    border-bottom: 1px solid #f7fafc;
    position: relative;
    padding-left: 2rem;
}

.highlights-list li:before {
    content: "★";
    position: absolute;
    left: 0;
    color: #ff6b35;
    font-weight: bold;
}

.itinerary-timeline {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.itinerary-item {
    display: flex;
    gap: 1rem;
    padding: 1.5rem;
    background: #f7fafc;
    border-radius: 8px;
    border-left: 4px solid #3182ce;
}

.itinerary-time {
    font-weight: 600;
    color: #3182ce;
    min-width: 80px;
    flex-shrink: 0;
}

.itinerary-content h3 {
    margin-bottom: 0.5rem;
    font-size: 1.1rem;
}

.itinerary-content p {
    color: #4a5568;
    margin-bottom: 0.5rem;
}

.itinerary-location {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    color: #718096;
    font-size: 0.875rem;
}

.includes-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
}

.includes-section h3 {
    margin-bottom: 1rem;
    color: #1a202c;
}

.includes-list {
    list-style: none;
    margin: 0;
    padding: 0;
}

.includes-list li {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 0;
    font-size: 0.875rem;
}

.included-item svg {
    color: #10b981;
}

.not-included-item svg {
    color: #ef4444;
}

.important-info {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
}

.info-section h3 {
    margin-bottom: 0.5rem;
    color: #1a202c;
    font-size: 1rem;
}

.info-section p {
    color: #4a5568;
    margin: 0;
}

/* Booking Sidebar - This is crucial */
.product-booking-sidebar {
    position: sticky;
    top: 2rem;
    height: fit-content;
}

.booking-card {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 2rem;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    margin-bottom: 2rem;
}

.booking-price {
    text-align: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #f7fafc;
}

.price-from {
    font-size: 0.875rem;
    color: #718096;
    display: block;
}

.price-amount {
    font-size: 2rem;
    font-weight: 700;
    color: #1a202c;
    display: block;
    margin: 0.25rem 0;
}

.price-per {
    font-size: 0.875rem;
    color: #718096;
    display: block;
}

.booking-guarantee {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    justify-content: center;
    margin-bottom: 1.5rem;
    font-size: 0.875rem;
    color: #10b981;
    text-align: center;
}

.woocommerce-booking-form {
    margin-bottom: 1.5rem;
}

.booking-features {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    padding-top: 1rem;
    border-top: 1px solid #f7fafc;
}

.booking-feature {
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
    font-size: 0.875rem;
    color: #4a5568;
    line-height: 1.4;
}

.booking-feature svg {
    color: #10b981;
    margin-top: 2px;
    flex-shrink: 0;
}

.related-products {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
}

.related-products h3 {
    margin-bottom: 1rem;
    color: #1a202c;
    font-size: 1.1rem;
}

.related-product-item {
    margin-bottom: 1rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #f7fafc;
}

.related-product-item:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.related-product-link {
    display: flex;
    gap: 1rem;
    text-decoration: none;
    color: inherit;
    transition: background-color 0.2s ease;
    padding: 0.5rem;
    border-radius: 6px;
}

.related-product-link:hover {
    background: #f7fafc;
}

.related-product-image {
    width: 80px;
    height: 60px;
    flex-shrink: 0;
    border-radius: 6px;
    overflow: hidden;
}

.related-product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.related-product-content h4 {
    font-size: 0.875rem;
    margin-bottom: 0.25rem;
    color: #1a202c;
    line-height: 1.3;
}

.related-product-meta {
    font-size: 0.75rem;
    color: #718096;
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

/* Reviews Section */
.reviews-section {
    background: #f7fafc;
    padding: 3rem 0;
    margin-top: 3rem;
}

/* Gallery Modal */
.gallery-modal .modal-content {
    max-width: 90vw;
    max-height: 90vh;
    padding: 0;
    border-radius: 12px;
    overflow: hidden;
}

.gallery-slider {
    position: relative;
}

.gallery-main-image {
    width: 100%;
    height: 70vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #000;
}

.gallery-main-image img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
}

.gallery-thumbnails {
    padding: 1rem;
    background: white;
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
    .product-content-grid {
        grid-template-columns: 1fr;
        gap: 2rem;
    }

    .product-gallery {
        grid-template-columns: 1fr;
        height: auto;
    }

    .main-image {
        height: 300px;
    }

    .thumbnail-grid {
        height: 150px;
        margin-top: 1rem;
    }

    .includes-grid {
        grid-template-columns: 1fr;
    }

    .important-info {
        grid-template-columns: 1fr;
    }

    .product-meta-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
    }

    .booking-card {
        margin-bottom: 1rem;
    }

    .product-booking-sidebar {
        position: static;
    }
}

/* WooCommerce Form Styles */
.woocommerce .single_add_to_cart_button {
    width: 100%;
    background: #3182ce;
    color: white;
    border: none;
    padding: 1rem 2rem;
    border-radius: 8px;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.woocommerce .single_add_to_cart_button:hover {
    background: #2c5aa0;
}

.woocommerce .single_add_to_cart_button.loading {
    opacity: 0.7;
    cursor: not-allowed;
}

.woocommerce form.cart {
    margin: 0;
}

.woocommerce form.cart .quantity {
    margin-bottom: 1rem;
}

.woocommerce form.cart .quantity input {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
}

/* WooCommerce Bookings Integration */
.wc-bookings-booking-form {
    background: #f7fafc;
    padding: 1.5rem;
    border-radius: 8px;
    margin-bottom: 1rem;
}

.wc-bookings-booking-form h3 {
    margin-bottom: 1rem;
    color: #1a202c;
}

.wc-bookings-booking-form .form-field {
    margin-bottom: 1rem;
}

.wc-bookings-booking-form label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: #344053;
}

.wc-bookings-booking-form input,
.wc-bookings-booking-form select {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: white;
}

.wc-bookings-booking-form input:focus,
.wc-bookings-booking-form select:focus {
    outline: none;
    border-color: #3182ce;
    box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.1);
}
</style>

<!-- Gallery Modal -->
<div id="gallery-modal" class="modal gallery-modal" style="display: none;">
    <div class="modal-overlay" onclick="closeGalleryModal()"></div>
    <div class="modal-content">
        <button class="modal-close" onclick="closeGalleryModal()">&times;</button>
        <div class="gallery-slider">
            <div class="gallery-main-image">
                <img id="gallery-main-img" src="" alt="">
            </div>
            <div class="gallery-thumbnails">
                <!-- Thumbnails will be populated by JavaScript -->
            </div>
        </div>
    </div>
</div>

<script>
// Gallery Modal Functions
function openGalleryModal(imageId = null) {
    const modal = document.getElementById('gallery-modal');
    const mainImg = document.getElementById('gallery-main-img');

    // Get all gallery images
    const galleryImages = [
        <?php if (has_post_thumbnail()) : ?>
            {
                src: '<?php echo esc_js(get_the_post_thumbnail_url(null, 'full')); ?>',
                alt: '<?php echo esc_js(get_the_title()); ?>'
            },
        <?php endif; ?>
        <?php if ($gallery) : ?>
            <?php foreach ($gallery as $image) : ?>
                {
                    src: '<?php echo esc_js($image['url']); ?>',
                    alt: '<?php echo esc_js($image['alt']); ?>'
                },
            <?php endforeach; ?>
        <?php endif; ?>
    ];

    if (galleryImages.length > 0) {
        mainImg.src = galleryImages[0].src;
        mainImg.alt = galleryImages[0].alt;
        modal.style.display = 'flex';
    }
}

function closeGalleryModal() {
    document.getElementById('gallery-modal').style.display = 'none';
}

// Share Product Function
function shareProduct() {
    if (navigator.share) {
        navigator.share({
            title: '<?php echo esc_js(get_the_title()); ?>',
            text: '<?php echo esc_js(wp_trim_words(get_the_excerpt(), 20)); ?>',
            url: window.location.href
        });
    } else {
        // Fallback: copy to clipboard
        navigator.clipboard.writeText(window.location.href).then(() => {
            if (typeof GetyourguideTheme !== 'undefined') {
                GetyourguideTheme.showNotification('Link copied to clipboard!', 'success');
            } else {
                alert('Link copied to clipboard!');
            }
        });
    }
}

// Initialize product page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeGalleryModal();
        }
    });
});
</script>

<?php get_footer('shop'); ?>
