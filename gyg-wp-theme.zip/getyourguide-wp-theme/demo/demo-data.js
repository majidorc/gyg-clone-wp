// Sample tour data for demo
const sampleTours = [
    {
        id: 1,
        title: "Skip-the-Line: Eiffel Tower Guided Tour",
        location: "Paris, France",
        image: "https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: 45,
        rating: 4.8,
        reviews: 2847,
        badge: "Bestseller",
        category: "attractions"
    },
    {
        id: 2,
        title: "London Eye: Fast-Track Entry Tickets",
        location: "London, UK",
        image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: 32,
        rating: 4.6,
        reviews: 1923,
        badge: "Popular",
        category: "attractions"
    },
    {
        id: 3,
        title: "Rome: Colosseum Underground Tour",
        location: "Rome, Italy",
        image: "https://images.unsplash.com/photo-1539037116277-4db20889f2d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: 65,
        rating: 4.9,
        reviews: 3456,
        badge: "Exclusive",
        category: "tours"
    },
    {
        id: 4,
        title: "Barcelona: Sagrada Familia Skip-the-Line",
        location: "Barcelona, Spain",
        image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: 28,
        rating: 4.7,
        reviews: 2134,
        badge: "Bestseller",
        category: "culture"
    },
    {
        id: 5,
        title: "Amsterdam: Canal Cruise with Dinner",
        location: "Amsterdam, Netherlands",
        image: "https://images.unsplash.com/photo-1534351590666-13e3e96b5017?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: 89,
        rating: 4.5,
        reviews: 876,
        badge: "Premium",
        category: "food"
    },
    {
        id: 6,
        title: "New York: Central Park Bike Tour",
        location: "New York, USA",
        image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: 42,
        rating: 4.4,
        reviews: 1567,
        badge: "Active",
        category: "outdoor"
    },
    {
        id: 7,
        title: "Tokyo: Traditional Tea Ceremony Experience",
        location: "Tokyo, Japan",
        image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: 55,
        rating: 4.8,
        reviews: 945,
        badge: "Cultural",
        category: "culture"
    },
    {
        id: 8,
        title: "Swiss Alps: Jungfraujoch Day Trip",
        location: "Interlaken, Switzerland",
        image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: 125,
        rating: 4.9,
        reviews: 2345,
        badge: "Adventure",
        category: "outdoor"
    }
];

// Search suggestions data
const searchSuggestions = [
    { text: "Paris", type: "destination" },
    { text: "London", type: "destination" },
    { text: "Rome", type: "destination" },
    { text: "Barcelona", type: "destination" },
    { text: "Amsterdam", type: "destination" },
    { text: "Eiffel Tower", type: "attraction" },
    { text: "Colosseum", type: "attraction" },
    { text: "London Eye", type: "attraction" },
    { text: "Sagrada Familia", type: "attraction" },
    { text: "Food tours", type: "activity" },
    { text: "Walking tours", type: "activity" },
    { text: "Museum tours", type: "activity" }
];

// Demo initialization
document.addEventListener('DOMContentLoaded', function() {
    initializeDemo();
    setupSearchFunctionality();
    setupCategoryTabs();
    renderTours('all');
});

function initializeDemo() {
    // Initialize wishlist from localStorage
    const savedWishlist = localStorage.getItem('demo_wishlist');
    if (savedWishlist) {
        try {
            window.userWishlist = JSON.parse(savedWishlist);
            updateWishlistCount();
        } catch (e) {
            window.userWishlist = [];
        }
    } else {
        window.userWishlist = [];
    }
}

function setupSearchFunctionality() {
    const searchInput = document.getElementById('search-input');
    const searchSuggestionsEl = document.getElementById('search-suggestions');
    
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const query = e.target.value.toLowerCase().trim();
            
            if (query.length > 0) {
                const filteredSuggestions = searchSuggestions.filter(item => 
                    item.text.toLowerCase().includes(query)
                ).slice(0, 6);
                
                displaySearchSuggestions(filteredSuggestions, searchSuggestionsEl);
            } else {
                searchSuggestionsEl.style.display = 'none';
            }
        });
        
        // Hide suggestions when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.search-container')) {
                searchSuggestionsEl.style.display = 'none';
            }
        });
    }
}

function displaySearchSuggestions(suggestions, container) {
    if (suggestions.length === 0) {
        container.style.display = 'none';
        return;
    }
    
    const html = suggestions.map(item => `
        <div class="suggestion-item" onclick="selectSuggestion('${item.text}')">
            <i class="fas fa-${item.type === 'destination' ? 'map-marker-alt' : item.type === 'attraction' ? 'monument' : 'compass'}"></i>
            <span>${item.text}</span>
        </div>
    `).join('');
    
    container.innerHTML = html;
    container.style.display = 'block';
}

function selectSuggestion(text) {
    const searchInput = document.getElementById('search-input');
    const searchSuggestionsEl = document.getElementById('search-suggestions');
    
    if (searchInput) {
        searchInput.value = text;
        searchSuggestionsEl.style.display = 'none';
        showNotification(`Searching for "${text}"...`, 'info');
    }
}

function setupCategoryTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            tabButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Get category and render tours
            const category = this.dataset.category;
            renderTours(category);
        });
    });
}

function renderTours(category) {
    const toursGrid = document.getElementById('tours-grid');
    
    if (!toursGrid) return;
    
    // Add loading state
    toursGrid.classList.add('loading');
    
    // Filter tours based on category
    let filteredTours = sampleTours;
    if (category !== 'all') {
        filteredTours = sampleTours.filter(tour => tour.category === category);
    }
    
    // Simulate loading delay
    setTimeout(() => {
        const html = filteredTours.map(tour => createTourCard(tour)).join('');
        toursGrid.innerHTML = html;
        toursGrid.classList.remove('loading');
        
        // Reattach event listeners for wishlist buttons
        attachWishlistEvents();
    }, 300);
}

function createTourCard(tour) {
    const isWishlisted = window.userWishlist.includes(tour.id);
    
    return `
        <div class="tour-card">
            <div class="tour-card-image">
                <img src="${tour.image}" alt="${tour.title}" loading="lazy">
                <div class="tour-card-badge">${tour.badge}</div>
                <button class="wishlist-icon ${isWishlisted ? 'active' : ''}" 
                        onclick="toggleWishlist(${tour.id})" 
                        aria-label="Add to wishlist">
                    <i class="fa${isWishlisted ? 's' : 'r'} fa-heart"></i>
                </button>
            </div>
            <div class="tour-card-content">
                <h3 class="tour-card-title">${tour.title}</h3>
                <div class="tour-card-location">
                    <i class="fas fa-map-marker-alt"></i>
                    ${tour.location}
                </div>
                <div class="tour-card-rating">
                    <div class="rating-stars">
                        ${'★'.repeat(Math.floor(tour.rating))}${'☆'.repeat(5 - Math.floor(tour.rating))}
                    </div>
                    <span class="rating-text">${tour.rating} (${tour.reviews} reviews)</span>
                </div>
                <div class="tour-card-price">
                    <div>
                        <span class="price-from">From</span>
                        <span class="price">$${tour.price}</span>
                    </div>
                    <button class="book-btn" onclick="bookTour(${tour.id})">Book now</button>
                </div>
            </div>
        </div>
    `;
}

function attachWishlistEvents() {
    // This function ensures wishlist buttons work after re-rendering
    // The onclick attributes handle the functionality
}

function toggleWishlist(tourId) {
    const index = window.userWishlist.indexOf(tourId);
    
    if (index > -1) {
        window.userWishlist.splice(index, 1);
        showNotification('Removed from wishlist', 'success');
    } else {
        window.userWishlist.push(tourId);
        showNotification('Added to wishlist', 'success');
    }
    
    // Save to localStorage
    localStorage.setItem('demo_wishlist', JSON.stringify(window.userWishlist));
    
    // Update UI
    updateWishlistCount();
    updateWishlistIcon(tourId);
}

function updateWishlistIcon(tourId) {
    const wishlistButtons = document.querySelectorAll(`[onclick="toggleWishlist(${tourId})"]`);
    const isWishlisted = window.userWishlist.includes(tourId);
    
    wishlistButtons.forEach(button => {
        const icon = button.querySelector('i');
        if (isWishlisted) {
            button.classList.add('active');
            icon.className = 'fas fa-heart';
        } else {
            button.classList.remove('active');
            icon.className = 'far fa-heart';
        }
    });
}

function updateWishlistCount() {
    const wishlistCountEl = document.querySelector('.wishlist-count');
    if (wishlistCountEl) {
        wishlistCountEl.textContent = window.userWishlist.length;
    }
}

function bookTour(tourId) {
    const tour = sampleTours.find(t => t.id === tourId);
    if (tour) {
        showNotification(`Booking "${tour.title}" - This is a demo!`, 'info');
    }
}

function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    if (!notification) return;
    
    notification.textContent = message;
    notification.className = `notification ${type} show`;
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// Initialize wishlist array
window.userWishlist = [];