/**
 * GetYourGuide Clone Theme - Main JavaScript - WooCommerce Integration
 */

(function($) {
    'use strict';

    // DOM Ready
    $(document).ready(function() {
        initializeTheme();
    });

    // Initialize all theme functionality
    function initializeTheme() {
        initMobileMenu();
        initSearchFunctionality();
        initWishlistFunctionality();
        initUserDropdown();
        initCategoryTabs();
        initModalFunctionality();
        initSmoothScrolling();
        initLazyLoading();
        initTooltips();
        initScrollEffects();
        initWooCommerceIntegration();
    }

    // Mobile Menu
    function initMobileMenu() {
        const mobileToggle = $('#mobile-menu-toggle');
        const mobileNav = $('#mobile-navigation');

        mobileToggle.on('click', function() {
            const isOpen = mobileNav.is(':visible');

            if (isOpen) {
                mobileNav.slideUp(300);
                $(this).removeClass('active');
            } else {
                mobileNav.slideDown(300);
                $(this).addClass('active');
            }
        });

        // Close mobile menu when clicking outside
        $(document).on('click', function(e) {
            if (!mobileToggle.is(e.target) && !mobileNav.is(e.target) && mobileNav.has(e.target).length === 0) {
                mobileNav.slideUp(300);
                mobileToggle.removeClass('active');
            }
        });

        // Close mobile menu on window resize
        $(window).on('resize', function() {
            if ($(window).width() > 768) {
                mobileNav.hide();
                mobileToggle.removeClass('active');
            }
        });
    }

    // Enhanced Search Functionality for WooCommerce
    function initSearchFunctionality() {
        const searchField = $('#search-field, .search-input, .search-input-shop');
        const searchResults = $('#search-results');
        let searchTimeout;
        let cache = {};

        searchField.each(function() {
            const $field = $(this);
            const $results = $field.closest('form').find('.search-results-dropdown') || searchResults;

            $field.on('input', function() {
                clearTimeout(searchTimeout);
                const query = $(this).val().trim();

                if (query.length < 2) {
                    $results.hide();
                    return;
                }

                // Check cache first
                if (cache[query]) {
                    displaySearchResults(cache[query], $results);
                    return;
                }

                searchTimeout = setTimeout(() => {
                    performAjaxSearch(query, $results);
                }, 300);
            });

            // Hide search results when clicking outside
            $(document).on('click', function(e) {
                if (!$field.is(e.target) && !$results.is(e.target) && $results.has(e.target).length === 0) {
                    $results.hide();
                }
            });
        });

        function performAjaxSearch(query, $results) {
            $results.html('<div class="search-loading">Searching...</div>').show();

            if (typeof getyourguide_ajax !== 'undefined') {
                $.ajax({
                    url: getyourguide_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'getyourguide_search',
                        search_term: query,
                        nonce: getyourguide_ajax.nonce
                    },
                    success: function(response) {
                        cache[query] = response;
                        displaySearchResults(response, $results);
                    },
                    error: function() {
                        $results.html('<div class="search-error">Search failed. Please try again.</div>');
                    }
                });
            } else {
                // Fallback to client-side search
                setTimeout(() => {
                    const results = performClientSearch(query);
                    cache[query] = results;
                    displaySearchResults(results, $results);
                }, 300);
            }
        }

        function displaySearchResults(results, $results) {
            if (!results || results.length === 0) {
                $results.html('<div class="search-no-results">No results found.</div>').show();
                return;
            }

            let html = '';
            results.forEach((result, index) => {
                html += `
                    <div class="search-result-item ${index === 0 ? 'highlighted' : ''}" data-url="${result.url}">
                        <img src="${result.image}" alt="${result.title}" class="search-result-image">
                        <div class="search-result-content">
                            <div class="search-result-title">${result.title}</div>
                            <div class="search-result-meta">
                                ${result.price ? result.price + ' • ' : ''}
                                ${result.rating ? '★ ' + result.rating + ' • ' : ''}
                                ${result.duration || ''}
                            </div>
                        </div>
                    </div>
                `;
            });

            $results.html(html).show();

            // Add click handlers
            $results.find('.search-result-item').on('click', function() {
                window.location.href = $(this).data('url');
            });
        }
    }

    // Enhanced Wishlist Functionality for WooCommerce
    function initWishlistFunctionality() {
        // Initialize wishlist for logged-in users
        if (typeof getyourguide_ajax !== 'undefined' && getyourguide_ajax.user_logged_in) {
            initLoggedInWishlist();
        } else {
            initGuestWishlist();
        }

        function initLoggedInWishlist() {
            // Wishlist button click handler for logged-in users
            $(document).on('click', '.tour-wishlist, .product-action-btn.wishlist-btn', function(e) {
                e.preventDefault();
                e.stopPropagation();

                const $button = $(this);
                const productId = $button.data('product-id');
                const isInWishlist = $button.hasClass('active');

                if (!productId) return;

                // Show loading state
                $button.addClass('loading').prop('disabled', true);

                const action = isInWishlist ? 'remove_from_wishlist' : 'add_to_wishlist';

                $.ajax({
                    url: getyourguide_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: action,
                        product_id: productId,
                        nonce: getyourguide_ajax.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $button.toggleClass('active');
                            updateWishlistButton($button, !isInWishlist);
                            showNotification(response.data, 'success');
                            updateWishlistCount();
                        } else {
                            showNotification(response.data || 'Error updating wishlist', 'error');
                        }
                    },
                    error: function() {
                        showNotification('Error updating wishlist', 'error');
                    },
                    complete: function() {
                        $button.removeClass('loading').prop('disabled', false);
                    }
                });
            });
        }

        function initGuestWishlist() {
            let wishlist = JSON.parse(localStorage.getItem('getyourguide_wishlist') || '[]');

            // Update wishlist count on page load
            updateWishlistCount();

            // Initialize wishlist buttons
            $('.tour-wishlist, .product-action-btn.wishlist-btn').each(function() {
                const $button = $(this);
                const productId = $button.data('product-id')?.toString();

                if (productId && wishlist.includes(productId)) {
                    $button.addClass('active');
                    updateWishlistButton($button, true);
                }
            });

            // Wishlist button click handler for guests
            $(document).on('click', '.tour-wishlist, .product-action-btn.wishlist-btn', function(e) {
                e.preventDefault();
                e.stopPropagation();

                const $button = $(this);
                const productId = $button.data('product-id')?.toString();

                if (!productId) return;

                if (wishlist.includes(productId)) {
                    // Remove from wishlist
                    wishlist = wishlist.filter(id => id !== productId);
                    $button.removeClass('active');
                    updateWishlistButton($button, false);
                    showNotification('Removed from wishlist', 'success');
                } else {
                    // Add to wishlist
                    wishlist.push(productId);
                    $button.addClass('active');
                    updateWishlistButton($button, true);
                    showNotification('Added to wishlist', 'success');
                }

                localStorage.setItem('getyourguide_wishlist', JSON.stringify(wishlist));
                updateWishlistCount();
            });

            function updateWishlistCount() {
                const count = wishlist.length;
                const $counter = $('#wishlist-count');

                if ($counter.length) {
                    $counter.text(count);
                    $counter.toggle(count > 0);
                }
            }
        }

        function updateWishlistButton($button, isInWishlist) {
            const $text = $button.find('span, .wishlist-text');
            if ($text.length) {
                $text.text(isInWishlist ? 'Remove from wishlist' : 'Add to wishlist');
            }
        }
    }

    // WooCommerce Integration
    function initWooCommerceIntegration() {
        // Enhanced Add to Cart functionality
        $(document).on('click', '.single_add_to_cart_button', function(e) {
            const $button = $(this);
            const $form = $button.closest('form.cart');

            // Add loading state
            $button.addClass('loading').text('Adding...');

            // Handle booking form validation if present
            if ($form.find('.wc-bookings-booking-form').length) {
                // Validate booking form
                if (!validateBookingForm($form)) {
                    e.preventDefault();
                    $button.removeClass('loading').text('Book Now');
                    return false;
                }
            }
        });

        // Update cart count after successful add to cart
        $(document.body).on('added_to_cart', function(event, fragments, cart_hash, $button) {
            // Update cart count in header
            updateCartCount();

            // Show success notification
            showNotification('Product added to cart!', 'success');

            // Reset button state
            $button.removeClass('loading').text('Added!');
            setTimeout(() => {
                $button.text('Book Now');
            }, 2000);
        });

        // Cart fragments update
        $(document.body).on('wc_fragments_refreshed', function() {
            updateCartCount();
        });

        function validateBookingForm($form) {
            let isValid = true;

            // Check required booking fields
            $form.find('input[required], select[required]').each(function() {
                if (!$(this).val()) {
                    $(this).addClass('error');
                    isValid = false;
                } else {
                    $(this).removeClass('error');
                }
            });

            if (!isValid) {
                showNotification('Please fill in all required booking details', 'error');
            }

            return isValid;
        }

        function updateCartCount() {
            // Update cart count from WooCommerce fragments or AJAX
            if (typeof getyourguide_ajax !== 'undefined') {
                $.get(getyourguide_ajax.wc_ajax_url.replace('%%endpoint%%', 'get_cart_count'))
                    .done(function(response) {
                        if (response && response.count !== undefined) {
                            const $cartCount = $('.cart-count');
                            $cartCount.text(response.count);
                            $cartCount.toggle(response.count > 0);
                        }
                    });
            }
        }
    }

    // User Dropdown
    function initUserDropdown() {
        const $toggle = $('#user-menu-toggle');
        const $dropdown = $('#user-dropdown');

        $toggle.on('click', function(e) {
            e.preventDefault();
            $dropdown.toggle();
        });

        // Close dropdown when clicking outside
        $(document).on('click', function(e) {
            if (!$toggle.is(e.target) && !$dropdown.is(e.target) && $dropdown.has(e.target).length === 0) {
                $dropdown.hide();
            }
        });
    }

    // Category Tabs for Product Filtering
    function initCategoryTabs() {
        $('.tab-button').on('click', function() {
            const category = $(this).data('category');

            // Update active tab
            $('.tab-button').removeClass('active');
            $(this).addClass('active');

            // Filter product cards with animation
            $('.tour-card-woocommerce, .tour-card').each(function() {
                const $card = $(this);
                const cardCategory = $card.find('.tour-category').text().toLowerCase();

                if (category === 'all' || cardCategory.includes(category.replace('-', ' '))) {
                    $card.fadeIn(300);
                } else {
                    $card.fadeOut(300);
                }
            });
        });
    }

    // Modal Functionality
    function initModalFunctionality() {
        // Newsletter modal
        const $modal = $('#newsletter-modal');
        const $closeBtn = $('#newsletter-close');
        const $overlay = $modal.find('.modal-overlay');

        // Show newsletter modal after delay (if not shown before)
        if (!localStorage.getItem('newsletter_shown')) {
            setTimeout(() => {
                $modal.fadeIn(300);
            }, 30000);
        }

        // Close modal handlers
        $closeBtn.add($overlay).on('click', function() {
            $modal.fadeOut(300);
            localStorage.setItem('newsletter_shown', 'true');
        });

        // Newsletter form submission
        $('#newsletter-form, #homepage-newsletter, #shop-newsletter').on('submit', function(e) {
            e.preventDefault();
            const email = $(this).find('input[type="email"]').val();

            // Simulate newsletter signup
            showNotification('Thank you for subscribing!', 'success');
            $modal.fadeOut(300);
            localStorage.setItem('newsletter_shown', 'true');
            $(this).find('input[type="email"]').val('');
        });

        // Close modal with Escape key
        $(document).on('keydown', function(e) {
            if (e.keyCode === 27 && $modal.is(':visible')) {
                $modal.fadeOut(300);
            }
        });
    }

    // Smooth Scrolling
    function initSmoothScrolling() {
        $('a[href^="#"]').on('click', function(e) {
            const target = $(this.getAttribute('href'));

            if (target.length) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: target.offset().top - 80
                }, 600);
            }
        });
    }

    // Lazy Loading for Images
    function initLazyLoading() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        img.classList.add('loaded');
                        imageObserver.unobserve(img);
                    }
                });
            });

            $('img[data-src]').each(function() {
                imageObserver.observe(this);
            });
        }
    }

    // Tooltips
    function initTooltips() {
        $('[data-tooltip]').each(function() {
            const $element = $(this);
            const text = $element.data('tooltip');

            $element.hover(
                function() {
                    const $tooltip = $('<div class="tooltip">' + text + '</div>');
                    $('body').append($tooltip);

                    const offset = $element.offset();
                    $tooltip.css({
                        top: offset.top - $tooltip.outerHeight() - 10,
                        left: offset.left + ($element.outerWidth() / 2) - ($tooltip.outerWidth() / 2)
                    }).fadeIn(200);
                },
                function() {
                    $('.tooltip').remove();
                }
            );
        });
    }

    // Scroll Effects
    function initScrollEffects() {
        let lastScrollTop = 0;
        const $header = $('.site-header');

        $(window).on('scroll', function() {
            const scrollTop = $(this).scrollTop();

            // Hide/show header on scroll
            if (scrollTop > lastScrollTop && scrollTop > 100) {
                $header.addClass('header-hidden');
            } else {
                $header.removeClass('header-hidden');
            }

            lastScrollTop = scrollTop;
        });
    }

    // Notification System
    function showNotification(message, type = 'info') {
        const $notification = $(`
            <div class="notification notification-${type}">
                <span class="notification-message">${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        `);

        $('body').append($notification);

        // Position notification
        $notification.css({
            position: 'fixed',
            top: '20px',
            right: '20px',
            zIndex: 10000,
            padding: '12px 16px',
            borderRadius: '6px',
            backgroundColor: type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3182ce',
            color: 'white',
            fontSize: '14px',
            fontWeight: '500',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
            transform: 'translateX(100%)',
            opacity: 0
        });

        // Animate in
        $notification.animate({
            transform: 'translateX(0)',
            opacity: 1
        }, 300);

        // Close button handler
        $notification.find('.notification-close').on('click', function() {
            closeNotification($notification);
        });

        // Auto close after 5 seconds
        setTimeout(() => {
            closeNotification($notification);
        }, 5000);

        function closeNotification($notif) {
            $notif.animate({
                transform: 'translateX(100%)',
                opacity: 0
            }, 300, function() {
                $notif.remove();
            });
        }
    }

    // Utility Functions
    window.GetyourguideTheme = {
        showNotification: showNotification,

        // Filter products
        filterProducts: function(category) {
            $('.tour-card-woocommerce, .tour-card').each(function() {
                const $card = $(this);
                const cardCategory = $card.find('.tour-category').text().toLowerCase();

                if (category === 'all' || cardCategory.includes(category.replace('-', ' '))) {
                    $card.show();
                } else {
                    $card.hide();
                }
            });
        },

        // Update sort
        updateSort: function(orderby) {
            const url = new URL(window.location);
            url.searchParams.set('orderby', orderby);
            window.location.href = url.toString();
        },

        // Add to cart with booking validation
        addToCart: function(productId, bookingData = {}) {
            if (typeof getyourguide_ajax === 'undefined') {
                showNotification('Cart functionality not available', 'error');
                return;
            }

            const data = {
                action: 'woocommerce_add_to_cart',
                product_id: productId,
                quantity: 1,
                ...bookingData
            };

            $.ajax({
                url: getyourguide_ajax.wc_ajax_url.replace('%%endpoint%%', 'add_to_cart'),
                type: 'POST',
                data: data,
                success: function(response) {
                    if (response.error) {
                        showNotification(response.error_message || 'Error adding to cart', 'error');
                    } else {
                        showNotification('Product added to cart!', 'success');
                        // Trigger WooCommerce event
                        $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash]);
                    }
                },
                error: function() {
                    showNotification('Error adding to cart', 'error');
                }
            });
        }
    };

    // Client-side search fallback
    function performClientSearch(query) {
        const results = [];
        const productCards = $('.tour-card-woocommerce, .tour-card');

        productCards.each(function() {
            const $card = $(this);
            const title = $card.find('.tour-title a, h3 a').text().toLowerCase();
            const description = $card.find('.tour-description').text().toLowerCase();

            if (title.includes(query.toLowerCase()) || description.includes(query.toLowerCase())) {
                const image = $card.find('.tour-image img, img').first().attr('src');
                const priceElement = $card.find('.tour-price, .price-amount');
                const ratingElement = $card.find('.rating-number');
                const durationElement = $card.find('.tour-duration');

                results.push({
                    title: $card.find('.tour-title a, h3 a').text(),
                    url: $card.find('.tour-title a, h3 a').attr('href'),
                    image: image || '',
                    price: priceElement.text() || '',
                    rating: ratingElement.text() || '',
                    duration: durationElement.text() || ''
                });
            }
        });

        return results.slice(0, 5); // Limit to 5 results
    }

})(jQuery);
